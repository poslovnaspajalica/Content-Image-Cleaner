<?php
/**
 * Plugin Name: Content Image Cleaner
 * Plugin URI: https://github.com/poslovnaspajalica/Content-Image-Cleaner
 * Description: Remove featured images and inline images from selected content in a date range, and optionally delete image attachments (images only).
 * Version: 1.0.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: BusinessClip Ltd
 * Author URI: https://poslovnaspajalica.hr
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: content-image-cleaner
 * Domain Path: /languages
 */

if (!defined('ABSPATH')) {
    exit;
}

final class BCIC_Image_Cleaner {
    const VERSION = '1.0.0';
    const SLUG = 'content-image-cleaner';
    const CAPABILITY = 'manage_options';

    const NONCE_ACTION = 'wic_run_cleanup';
    const NONCE_NAME = 'wic_nonce';

    const OPT_AUDIT_ENABLED = 'wic_audit_enabled';
    const OPT_AUDIT_FILE_ENABLED = 'wic_audit_file_enabled';
    const OPT_AUDIT_WPLOG_ENABLED = 'wic_audit_wplog_enabled';
    const OPT_REQUIRE_DELETE_CONFIRM = 'wic_require_delete_confirm';
    const OPT_AUDIT_LOG = 'wic_audit_log';

    const AUDIT_MAX_ENTRIES = 200;
    const AUDIT_FILE_MAX_BYTES = 2097152; // 2 MB

    public static function init(): void {
        if (!is_admin()) {
            return;
        }
        add_action('init', [__CLASS__, 'load_textdomain']);
        add_action('admin_menu', [__CLASS__, 'admin_menu']);
        add_action('admin_enqueue_scripts', [__CLASS__, 'admin_enqueue']);
        add_action('admin_post_wic_security_save', [__CLASS__, 'handle_security_save']);
        add_action('admin_post_wic_audit_clear', [__CLASS__, 'handle_audit_clear']);
    }

    public static function load_textdomain(): void {
        // WordPress.org will auto-load translations from language packs.
        // For local/dev installs, load bundled .mo if present.
        $domain = 'content-image-cleaner';
        $locale = function_exists('determine_locale') ? determine_locale() : get_locale();
        $base = plugin_dir_path(__FILE__) . 'languages/';
        $candidates = [
            $base . $domain . '-' . $locale . '.mo',
            $base . $domain . '-' . strtolower(str_replace('-', '_', $locale)) . '.mo',
        ];
        $lang_only = preg_replace('/^([a-z]{2,3}).*$/i', '$1', (string) $locale);
        if (is_string($lang_only) && $lang_only !== '' && $lang_only !== $locale) {
            $candidates[] = $base . $domain . '-' . $lang_only . '.mo';
        }
        foreach ($candidates as $mofile) {
            if (is_string($mofile) && file_exists($mofile)) {
                load_textdomain($domain, $mofile);
                break;
            }
        }
    }

    public static function admin_menu(): void {
        add_menu_page(
            __('Content Image Cleaner', 'content-image-cleaner'),
            __('Content Image Cleaner', 'content-image-cleaner'),
            self::CAPABILITY,
            self::SLUG,
            [__CLASS__, 'render_page'],
            'dashicons-format-image',
            58
        );
    }

    public static function admin_enqueue(string $hook): void {
        // Top-level page
        if ($hook !== 'toplevel_page_' . self::SLUG) {
            return;
        }
        $base = plugin_dir_url(__FILE__);
        wp_enqueue_style('wic-admin', $base . 'assets/admin.css', [], self::VERSION);
    }

    public static function render_page(): void {
        if (!current_user_can(self::CAPABILITY)) {
            wp_die(esc_html__('Sorry, you are not allowed to access this page.', 'content-image-cleaner'));
        }

        // phpcs:disable WordPress.Security.NonceVerification.Recommended
        $tab = isset($_GET['tab']) ? sanitize_key(wp_unslash($_GET['tab'])) : 'cleaner';
        $tab = in_array($tab, ['cleaner', 'security'], true) ? $tab : 'cleaner';
        // phpcs:enable WordPress.Security.NonceVerification.Recommended

        $public_post_types = get_post_types(['public' => true], 'objects');
        $default_post_types = ['post', 'page'];
        $default_post_statuses = ['publish'];

        $result = null;
        $errors = [];

        $require_delete_confirm = self::is_require_delete_confirm_enabled();
        $audit_enabled = self::is_audit_enabled();
        $audit_log = self::get_audit_log();

        // phpcs:ignore WordPress.Security.NonceVerification.Missing
        if ($tab === 'cleaner' && isset($_POST['wic_submit'])) {
            check_admin_referer(self::NONCE_ACTION, self::NONCE_NAME);

        $post = is_array($_POST) ? wp_unslash($_POST) : []; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
        $start_date = isset($post['start_date']) ? sanitize_text_field((string) $post['start_date']) : '';
        $end_date = isset($post['end_date']) ? sanitize_text_field((string) $post['end_date']) : '';

        $post_types = isset($post['post_types']) ? (array) $post['post_types'] : [];
            $post_types = array_values(array_filter(array_map('sanitize_key', $post_types)));

        $post_statuses = isset($post['post_statuses']) ? (array) $post['post_statuses'] : [];
            $post_statuses = array_values(array_filter(array_map('sanitize_key', $post_statuses)));

        $do_featured = !empty($post['do_featured']);
        $do_content = !empty($post['do_content']);
            // Delete attachments options are currently disabled in UI (coming back in a future version).
            // Keep server-side hardening: ignore even if someone crafts a POST request.
            $do_delete_media = false;
            $do_delete_content_media = false;
        $dry_run = !empty($post['dry_run']);

            if ($start_date === '' || $end_date === '') {
                $errors[] = __('Pick a start and end date.', 'content-image-cleaner');
            }
            if (empty($post_types)) {
                $errors[] = __('Pick at least one content type (e.g. Posts/Pages).', 'content-image-cleaner');
            }
            if (!$do_featured && !$do_content && !$do_delete_media && !$do_delete_content_media) {
                $errors[] = __('Pick at least one action.', 'content-image-cleaner');
            }

        $confirm = isset($post['confirm_text']) ? sanitize_text_field((string) $post['confirm_text']) : '';
            if ($require_delete_confirm && ($do_delete_media || $do_delete_content_media) && !$dry_run && strtoupper(trim($confirm)) !== 'DELETE') {
                $errors[] = __('To permanently delete images, type: DELETE', 'content-image-cleaner');
            }

            if (empty($errors)) {
                $result = self::run_cleanup([
                    'start_date' => $start_date,
                    'end_date' => $end_date,
                    'post_types' => $post_types,
                    'post_statuses' => $post_statuses ?: $default_post_statuses,
                    'do_featured' => $do_featured,
                    'do_content' => $do_content,
                    'do_delete_media' => $do_delete_media,
                    'do_delete_content_media' => $do_delete_content_media,
                    'dry_run' => $dry_run,
                ]);
                self::audit_log('run_cleanup', [
                    'dry_run' => $dry_run ? 1 : 0,
                    'do_featured' => $do_featured ? 1 : 0,
                    'do_content' => $do_content ? 1 : 0,
                    'do_delete_media' => $do_delete_media ? 1 : 0,
                    'do_delete_content_media' => $do_delete_content_media ? 1 : 0,
                    'posts_processed' => (int) ($result['posts_processed'] ?? 0),
                    'attachments_deleted' => (int) ($result['attachments_deleted'] ?? 0),
                    'content_image_attachments_deleted' => (int) ($result['content_image_attachments_deleted'] ?? 0),
                ]);
            }
        }

        $logo_url = plugins_url('logo.png', __FILE__);

        ?>
        <div class="wrap wic-wrap">
            <div class="wic-header">
                <div class="wic-header-left">
                    <h1 class="wic-title"><?php echo esc_html__('Content Image Cleaner', 'content-image-cleaner'); ?></h1>
                    <p class="wic-subtitle">
                        <?php echo esc_html__('Clean featured images and inline images for a selected date range.', 'content-image-cleaner'); ?>
                    </p>
                </div>
                <div class="wic-header-right">
                    <img class="wic-logo" src="<?php echo esc_url($logo_url); ?>" alt="<?php echo esc_attr__('Content Image Cleaner', 'content-image-cleaner'); ?>">
                </div>
            </div>

            <h2 class="nav-tab-wrapper">
                <a class="nav-tab <?php echo $tab === 'cleaner' ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url(add_query_arg(['page' => self::SLUG, 'tab' => 'cleaner'], admin_url('admin.php'))); ?>">
                    <?php echo esc_html__('Cleaner', 'content-image-cleaner'); ?>
                </a>
                <a class="nav-tab wic-nav-tab-security <?php echo $tab === 'security' ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url(add_query_arg(['page' => self::SLUG, 'tab' => 'security'], admin_url('admin.php'))); ?>">
                    <?php echo esc_html__('Security settings', 'content-image-cleaner'); ?>
                </a>
            </h2>

            <?php if ($tab === 'cleaner') : ?>
                <div class="wic-card">
                    <p class="wic-lead">
                        <?php echo esc_html__('This tool can:', 'content-image-cleaner'); ?>
                        <strong><?php echo esc_html__('(1)', 'content-image-cleaner'); ?></strong> <?php echo esc_html__('remove featured images from content in the selected date range,', 'content-image-cleaner'); ?>
                        <strong><?php echo esc_html__('(2)', 'content-image-cleaner'); ?></strong> <?php echo esc_html__('remove inline images and image links from post content,', 'content-image-cleaner'); ?>
                        <strong><?php echo esc_html__('(3)', 'content-image-cleaner'); ?></strong> <?php echo esc_html__('optionally delete image attachments from the Media Library (including all sizes).', 'content-image-cleaner'); ?>
                        <br>
                        <strong><?php echo esc_html__('Images only.', 'content-image-cleaner'); ?></strong>
                        <?php echo esc_html__('This plugin does not delete PDFs/documents.', 'content-image-cleaner'); ?>
                    </p>
                </div>

                <?php if (!empty($errors)) : ?>
                    <div class="notice notice-error">
                        <p><strong><?php echo esc_html__('Errors:', 'content-image-cleaner'); ?></strong></p>
                        <ul>
                            <?php foreach ($errors as $e) : ?>
                                <li><?php echo esc_html($e); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <?php if (is_array($result)) : ?>
                    <div class="notice notice-success">
                        <p><strong><?php echo esc_html__('Done', 'content-image-cleaner'); ?><?php echo !empty($result['dry_run']) ? ' (' . esc_html__('DRY RUN', 'content-image-cleaner') . ')' : ''; ?>.</strong></p>
                        <ul>
                            <li><strong><?php echo esc_html__('Posts processed:', 'content-image-cleaner'); ?></strong> <?php echo (int) $result['posts_processed']; ?></li>
                            <li><strong><?php echo esc_html__('Featured images removed:', 'content-image-cleaner'); ?></strong> <?php echo (int) $result['featured_removed']; ?></li>
                            <li><strong><?php echo esc_html__('Contents updated:', 'content-image-cleaner'); ?></strong> <?php echo (int) $result['content_updated']; ?></li>
                            <li><strong><?php echo esc_html__('Image attachments processed:', 'content-image-cleaner'); ?></strong> <?php echo (int) $result['attachments_processed']; ?></li>
                            <li><strong><?php echo esc_html__('Images deleted:', 'content-image-cleaner'); ?></strong> <?php echo (int) $result['attachments_deleted']; ?></li>
                            <li><strong><?php echo esc_html__('Image URLs found in content:', 'content-image-cleaner'); ?></strong> <?php echo (int) $result['content_image_urls_found']; ?></li>
                            <li><strong><?php echo esc_html__('Image attachments found from content:', 'content-image-cleaner'); ?></strong> <?php echo (int) $result['content_image_attachments_found']; ?></li>
                            <li><strong><?php echo esc_html__('Image attachments deleted from content:', 'content-image-cleaner'); ?></strong> <?php echo (int) $result['content_image_attachments_deleted']; ?></li>
                        </ul>
                    </div>
                <?php endif; ?>

                <div class="wic-card">
                    <h2 class="wic-card-title"><?php echo esc_html__('Cleaner settings', 'content-image-cleaner'); ?></h2>
                    <form method="post" class="wic-form">
                        <?php wp_nonce_field(self::NONCE_ACTION, self::NONCE_NAME); ?>

                    <div class="wic-grid">
                        <label>
                            <span><?php echo esc_html__('Start date', 'content-image-cleaner'); ?></span>
                    <input type="date" id="start_date" name="start_date" value="<?php echo isset($post['start_date']) ? esc_attr((string) $post['start_date']) : ''; ?>" required>
                        </label>
                        <label>
                            <span><?php echo esc_html__('End date', 'content-image-cleaner'); ?></span>
                    <input type="date" id="end_date" name="end_date" value="<?php echo isset($post['end_date']) ? esc_attr((string) $post['end_date']) : ''; ?>" required>
                        </label>
                    </div>

                    <div class="wic-card-subsection">
                        <h3 class="wic-subtitle-h"><?php echo esc_html__('Content types', 'content-image-cleaner'); ?></h3>
                        <div class="wic-check-grid">
                            <?php foreach ($public_post_types as $pt_key => $pt_obj) : ?>
                                <?php
                                // phpcs:disable WordPress.Security.NonceVerification.Missing
                            $checked = isset($post['post_types'])
                                ? in_array($pt_key, (array) $post['post_types'], true)
                                    : in_array($pt_key, $default_post_types, true);
                                // phpcs:enable WordPress.Security.NonceVerification.Missing
                                ?>
                                <label class="wic-check">
                                    <input type="checkbox" name="post_types[]" value="<?php echo esc_attr($pt_key); ?>" <?php checked($checked); ?>>
                                    <span><?php echo esc_html($pt_obj->labels->singular_name); ?> <code><?php echo esc_html($pt_key); ?></code></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div class="wic-card-subsection">
                        <h3 class="wic-subtitle-h"><?php echo esc_html__('Post statuses', 'content-image-cleaner'); ?></h3>
                        <div class="wic-check-grid">
                            <?php
                            $statuses = get_post_stati(['internal' => false], 'objects');
                            foreach ($statuses as $st_key => $st_obj) :
                                // phpcs:disable WordPress.Security.NonceVerification.Missing
                            $checked = isset($post['post_statuses'])
                                ? in_array($st_key, (array) $post['post_statuses'], true)
                                    : in_array($st_key, $default_post_statuses, true);
                                // phpcs:enable WordPress.Security.NonceVerification.Missing
                                ?>
                                <label class="wic-check">
                                    <input type="checkbox" name="post_statuses[]" value="<?php echo esc_attr($st_key); ?>" <?php checked($checked); ?>>
                                    <span><?php echo esc_html($st_obj->label); ?></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div class="wic-card-subsection">
                        <h3 class="wic-subtitle-h"><?php echo esc_html__('Actions', 'content-image-cleaner'); ?></h3>
                        <div class="wic-actions">
                            <label class="wic-check wic-check-full">
                            <input type="checkbox" name="do_featured" value="1" <?php checked(!empty($post) ? !empty($post['do_featured']) : true); ?>>
                                <span><?php echo esc_html__('Remove featured images for posts in range (by post date).', 'content-image-cleaner'); ?></span>
                            </label>
                            <label class="wic-check wic-check-full">
                            <input type="checkbox" name="do_content" value="1" <?php checked(!empty($post['do_content'])); ?>>
                                <span><?php echo esc_html__('Remove inline images and image links from HTML content.', 'content-image-cleaner'); ?></span>
                            </label>
                            <label class="wic-check wic-check-full is-disabled">
                                <input type="checkbox" name="do_delete_media" value="1" disabled <?php checked(false); ?>>
                                <span>
                                    <?php echo esc_html__('Delete image attachments in range (by attachment upload date) + all sizes. Images only.', 'content-image-cleaner'); ?>
                                    <span class="wic-badge-pro" aria-hidden="true">PRO</span>
                                </span>
                            </label>
                            <label class="wic-check wic-check-full is-disabled">
                                <input type="checkbox" name="do_delete_content_media" value="1" disabled <?php checked(false); ?>>
                                <span>
                                    <?php echo esc_html__('Delete image attachments discovered from processed content (caution: could be used elsewhere).', 'content-image-cleaner'); ?>
                                    <span class="wic-badge-pro" aria-hidden="true">PRO</span>
                                </span>
                            </label>
                        </div>
                    </div>

                    <div class="wic-card-subsection">
                        <h3 class="wic-subtitle-h"><?php echo esc_html__('Mode', 'content-image-cleaner'); ?></h3>
                        <label class="wic-check wic-check-full">
                            <input type="checkbox" name="dry_run" value="1" <?php checked(!empty($post) ? !empty($post['dry_run']) : true); ?>>
                            <span><?php echo esc_html__('Dry run (calculate only / no changes).', 'content-image-cleaner'); ?></span>
                        </label>
                    </div>

                    <div class="wic-grid">
                        <label>
                            <span><?php echo esc_html__('Delete confirmation', 'content-image-cleaner'); ?></span>
                            <input type="text" id="confirm_text" name="confirm_text" value="" placeholder="<?php echo esc_attr__('Type DELETE to permanently delete images', 'content-image-cleaner'); ?>">
                        </label>
                    </div>

                        <div class="wic-form-actions">
                            <button type="submit" class="button button-primary" name="wic_submit" value="1"><?php echo esc_html__('Run', 'content-image-cleaner'); ?></button>
                        </div>
                    </form>
                </div>
            <?php endif; ?>

            <?php if ($tab === 'security') : ?>
                <div class="wic-card">
                    <h2 class="wic-card-title"><?php echo esc_html__('Before you run destructive actions', 'content-image-cleaner'); ?></h2>
                    <div class="notice notice-warning" style="margin: 10px 0 12px 0; padding: 10px 12px;">
                        <p style="margin: 0;">
                            <strong><?php echo esc_html__('Warning:', 'content-image-cleaner'); ?></strong>
                            <?php echo esc_html__('This plugin can modify post content and permanently delete Media Library image attachments. These actions are irreversible.', 'content-image-cleaner'); ?>
                        </p>
                        <p style="margin: 8px 0 0 0;">
                            <?php echo esc_html__('Always take a full backup (database + uploads) and run a dry run first.', 'content-image-cleaner'); ?>
                        </p>
                    </div>
                </div>

                <div class="wic-card">
                    <h2 class="wic-card-title"><?php echo esc_html__('Security options', 'content-image-cleaner'); ?></h2>
                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                        <input type="hidden" name="action" value="wic_security_save">
                        <?php wp_nonce_field('wic_security_save', 'wic_security_nonce'); ?>

                        <p style="margin: 0 0 10px 0;">
                            <label>
                                <input type="checkbox" name="wic_require_delete_confirm" value="1" <?php checked($require_delete_confirm, true); ?>>
                                <?php echo esc_html__('Require typing DELETE for destructive actions (recommended).', 'content-image-cleaner'); ?>
                            </label>
                        </p>

                        <p style="margin: 0 0 10px 0;">
                            <label>
                                <input type="checkbox" name="wic_audit_enabled" value="1" <?php checked($audit_enabled, true); ?>>
                                <?php echo esc_html__('Enable audit log (recommended).', 'content-image-cleaner'); ?>
                            </label>
                        </p>

                        <p style="margin: 0 0 10px 0;">
                            <label>
                                <input type="checkbox" name="wic_audit_file_enabled" value="1" <?php checked((bool) get_option(self::OPT_AUDIT_FILE_ENABLED, 1), true); ?>>
                                <?php echo esc_html__('Write audit log to file (uploads) (recommended).', 'content-image-cleaner'); ?>
                            </label>
                        </p>

                        <p style="margin: 0 0 12px 0;">
                            <label>
                                <input type="checkbox" name="wic_audit_wplog_enabled" value="1" <?php checked((bool) get_option(self::OPT_AUDIT_WPLOG_ENABLED, 0), true); ?>>
                                <?php echo esc_html__('Write audit log to WP/PHP error log (optional).', 'content-image-cleaner'); ?>
                            </label>
                        </p>

                        <p style="margin: 0;">
                            <button type="submit" class="button button-primary"><?php echo esc_html__('Save security settings', 'content-image-cleaner'); ?></button>
                        </p>
                    </form>
                </div>

                <div class="wic-card">
                    <h2 class="wic-card-title"><?php echo esc_html__('Audit log', 'content-image-cleaner'); ?></h2>
                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="margin: 10px 0 12px 0;">
                        <input type="hidden" name="action" value="wic_audit_clear">
                        <?php wp_nonce_field('wic_audit_clear', 'wic_audit_clear_nonce'); ?>
                        <button type="submit" class="button button-secondary" onclick="return confirm('<?php echo esc_js(__('Clear audit log?', 'content-image-cleaner')); ?>');">
                            <?php echo esc_html__('Clear audit log', 'content-image-cleaner'); ?>
                        </button>
                    </form>

                    <?php if (empty($audit_log)) : ?>
                        <p><?php echo esc_html__('Audit log is empty.', 'content-image-cleaner'); ?></p>
                    <?php else : ?>
                        <div style="overflow:auto;">
                            <table class="widefat striped">
                                <thead>
                                <tr>
                                    <th><?php echo esc_html__('Time', 'content-image-cleaner'); ?></th>
                                    <th><?php echo esc_html__('User', 'content-image-cleaner'); ?></th>
                                    <th><?php echo esc_html__('Action', 'content-image-cleaner'); ?></th>
                                    <th><?php echo esc_html__('Details', 'content-image-cleaner'); ?></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php
                                $shown = array_slice($audit_log, 0, 50);
                                foreach ($shown as $row) :
                                    $t = isset($row['time']) ? (string) $row['time'] : '';
                                    $u = isset($row['user']) ? (string) $row['user'] : '';
                                    $a = isset($row['action']) ? (string) $row['action'] : '';
                                    $d = isset($row['details']) ? wp_json_encode($row['details'], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) : '';
                                    ?>
                                    <tr>
                                        <td><?php echo esc_html($t); ?></td>
                                        <td><?php echo esc_html($u); ?></td>
                                        <td><?php echo esc_html($a); ?></td>
                                        <td><code><?php echo esc_html($d); ?></code></td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
        <?php
    }

    public static function handle_security_save(): void {
        if (!current_user_can(self::CAPABILITY)) {
            wp_die(esc_html__('Sorry, you are not allowed to do this.', 'content-image-cleaner'));
        }
        check_admin_referer('wic_security_save', 'wic_security_nonce');

        $post = is_array($_POST) ? wp_unslash($_POST) : []; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
        $audit_enabled = !empty($post['wic_audit_enabled']) ? 1 : 0;
        $audit_file_enabled = !empty($post['wic_audit_file_enabled']) ? 1 : 0;
        $audit_wplog_enabled = !empty($post['wic_audit_wplog_enabled']) ? 1 : 0;
        $require_delete_confirm = !empty($post['wic_require_delete_confirm']) ? 1 : 0;

        update_option(self::OPT_AUDIT_ENABLED, $audit_enabled, false);
        update_option(self::OPT_AUDIT_FILE_ENABLED, $audit_file_enabled, false);
        update_option(self::OPT_AUDIT_WPLOG_ENABLED, $audit_wplog_enabled, false);
        update_option(self::OPT_REQUIRE_DELETE_CONFIRM, $require_delete_confirm, false);

        self::audit_log('security_save', [
            'audit_enabled' => (int) $audit_enabled,
            'audit_file_enabled' => (int) $audit_file_enabled,
            'audit_wplog_enabled' => (int) $audit_wplog_enabled,
            'require_delete_confirm' => (int) $require_delete_confirm,
        ]);

        wp_safe_redirect(add_query_arg(['page' => self::SLUG, 'tab' => 'security'], admin_url('admin.php')));
        exit;
    }

    public static function handle_audit_clear(): void {
        if (!current_user_can(self::CAPABILITY)) {
            wp_die(esc_html__('Sorry, you are not allowed to do this.', 'content-image-cleaner'));
        }
        check_admin_referer('wic_audit_clear', 'wic_audit_clear_nonce');
        update_option(self::OPT_AUDIT_LOG, [], false);
        wp_safe_redirect(add_query_arg(['page' => self::SLUG, 'tab' => 'security'], admin_url('admin.php')));
        exit;
    }

    private static function run_cleanup(array $args): array {
        $start = $args['start_date'] . ' 00:00:00';
        $end = $args['end_date'] . ' 23:59:59';

        $dry_run = (bool) $args['dry_run'];
        $do_featured = (bool) $args['do_featured'];
        $do_content = (bool) $args['do_content'];
        $do_delete_media = (bool) $args['do_delete_media'];
        $do_delete_content_media = (bool) ($args['do_delete_content_media'] ?? false);

        $posts_processed = 0;
        $featured_removed = 0;
        $content_updated = 0;
        $attachments_processed = 0;
        $attachments_deleted = 0;
        $content_image_urls = [];
        $content_image_attachments_found = 0;
        $content_image_attachments_deleted = 0;

        if ($do_featured || $do_content) {
            $paged = 1;
            $per_page = 100;
            do {
                $q = new WP_Query([
                    'post_type' => $args['post_types'],
                    'post_status' => $args['post_statuses'],
                    'posts_per_page' => $per_page,
                    'paged' => $paged,
                    'fields' => 'ids',
                    'orderby' => 'ID',
                    'order' => 'ASC',
                    'date_query' => [[
                        'after' => $start,
                        'before' => $end,
                        'inclusive' => true,
                        'column' => 'post_date',
                    ]],
                    'no_found_rows' => true,
                ]);
                if (empty($q->posts)) {
                    break;
                }

                foreach ($q->posts as $post_id) {
                    $posts_processed++;

                    if ($do_featured) {
                        $thumb_id = get_post_thumbnail_id($post_id);
                        if ($thumb_id) {
                            if (!$dry_run) {
                                delete_post_thumbnail($post_id);
                            }
                            $featured_removed++;
                        }
                    }

                    if ($do_content) {
                        $post = get_post($post_id);
                        if ($post && is_string($post->post_content) && $post->post_content !== '') {
                            $strip = self::strip_images_and_image_links_from_html($post->post_content);
                            $new = $strip['html'];
                            if (!empty($strip['urls']) && is_array($strip['urls'])) {
                                $content_image_urls = array_merge($content_image_urls, $strip['urls']);
                            }
                            $new = preg_replace('/\\[(gallery|caption)\\b[^\\]]*\\]/i', '', $new);
                            $new = preg_replace('/\\[\\/(gallery|caption)\\]/i', '', $new);

                            if (is_string($new) && $new !== $post->post_content) {
                                if (!$dry_run) {
                                    wp_update_post([
                                        'ID' => $post_id,
                                        'post_content' => $new,
                                    ]);
                                }
                                $content_updated++;
                            }
                        }
                    }
                }

                $paged++;
            } while (true);
        }

        if ($do_delete_content_media && !empty($content_image_urls)) {
            $content_image_urls = array_values(array_unique(array_filter(array_map('strval', $content_image_urls))));
            foreach ($content_image_urls as $url) {
                $att_id = attachment_url_to_postid($url);
                if (!$att_id) {
                    continue;
                }
                $mime = get_post_mime_type($att_id);
                if (!is_string($mime) || strpos($mime, 'image/') !== 0) {
                    continue;
                }
                $content_image_attachments_found++;
                if (!$dry_run) {
                    $deleted = wp_delete_attachment($att_id, true);
                    if ($deleted) {
                        $content_image_attachments_deleted++;
                    }
                } else {
                    $content_image_attachments_deleted++;
                }
            }
        }

        if ($do_delete_media) {
            $paged = 1;
            $per_page = 100;
            do {
                $q = new WP_Query([
                    'post_type' => 'attachment',
                    'post_status' => 'inherit',
                    'post_mime_type' => 'image',
                    'posts_per_page' => $per_page,
                    'paged' => $paged,
                    'fields' => 'ids',
                    'orderby' => 'ID',
                    'order' => 'ASC',
                    'date_query' => [[
                        'after' => $start,
                        'before' => $end,
                        'inclusive' => true,
                        'column' => 'post_date',
                    ]],
                    'no_found_rows' => true,
                ]);
                if (empty($q->posts)) {
                    break;
                }

                foreach ($q->posts as $att_id) {
                    $mime = get_post_mime_type($att_id);
                    if (!is_string($mime) || strpos($mime, 'image/') !== 0) {
                        continue;
                    }
                    $attachments_processed++;
                    if (!$dry_run) {
                        $deleted = wp_delete_attachment($att_id, true);
                        if ($deleted) {
                            $attachments_deleted++;
                        }
                    } else {
                        $attachments_deleted++;
                    }
                }

                $paged++;
            } while (true);
        }

        return [
            'dry_run' => $dry_run,
            'posts_processed' => $posts_processed,
            'featured_removed' => $featured_removed,
            'content_updated' => $content_updated,
            'attachments_processed' => $attachments_processed,
            'attachments_deleted' => $attachments_deleted,
            'content_image_urls_found' => count(array_unique(array_filter(array_map('strval', $content_image_urls)))),
            'content_image_attachments_found' => $content_image_attachments_found,
            'content_image_attachments_deleted' => $content_image_attachments_deleted,
        ];
    }

    private static function strip_images_and_image_links_from_html(string $html): array {
        if (stripos($html, '<img') === false && stripos($html, 'wp-content/uploads') === false) {
            return [
                'html' => $html,
                'urls' => [],
            ];
        }

        $internal_errors = libxml_use_internal_errors(true);

        $dom = new DOMDocument();
        $wrapped = '<!DOCTYPE html><html><head><meta charset="utf-8"></head><body>' . $html . '</body></html>';
        $dom->loadHTML($wrapped, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
        libxml_clear_errors();
        libxml_use_internal_errors($internal_errors);

        $xpath = new DOMXPath($dom);
        $urls = [];

        foreach ($xpath->query('//img|//source') as $node) {
            if ($node instanceof DOMElement) {
                foreach (['src', 'data-src'] as $attr) {
                    $u = $node->getAttribute($attr);
                    if (is_string($u) && $u !== '') {
                        $urls[] = $u;
                    }
                }
                $srcset = $node->getAttribute('srcset');
                if (is_string($srcset) && $srcset !== '') {
                    $parts = array_map('trim', explode(',', $srcset));
                    foreach ($parts as $p) {
                        $p = trim(preg_replace('/\\s+\\d+[wx]\\s*$/i', '', $p));
                        if ($p !== '') {
                            $urls[] = $p;
                        }
                    }
                }
            }
            if ($node && $node->parentNode) {
                $node->parentNode->removeChild($node);
            }
        }

        foreach ($xpath->query('//a[@href]') as $a) {
            if (!$a instanceof DOMElement) {
                continue;
            }
            $href = $a->getAttribute('href');
            if (!is_string($href) || $href === '') {
                continue;
            }
            $is_image_link = (bool) preg_match('/\\.(jpe?g|png|gif|webp|avif|heic)(\\?.*)?$/i', $href);
            if (!$is_image_link) {
                continue;
            }
            $urls[] = $href;

            $parent = $a->parentNode;
            if (!$parent) {
                continue;
            }
            if ($a->hasChildNodes()) {
                while ($a->firstChild) {
                    $parent->insertBefore($a->firstChild, $a);
                }
            }
            $parent->removeChild($a);
        }

        $body = $dom->getElementsByTagName('body')->item(0);
        if (!$body) {
            return [
                'html' => $html,
                'urls' => [],
            ];
        }

        $out = '';
        foreach ($body->childNodes as $child) {
            $out .= $dom->saveHTML($child);
        }

        return [
            'html' => $out,
            'urls' => $urls,
        ];
    }

    private static function is_audit_enabled(): bool {
        return (bool) get_option(self::OPT_AUDIT_ENABLED, 1);
    }

    private static function is_require_delete_confirm_enabled(): bool {
        return (bool) get_option(self::OPT_REQUIRE_DELETE_CONFIRM, 1);
    }

    private static function audit_log(string $action, array $details = []): void {
        if (!self::is_audit_enabled()) {
            return;
        }
        $user = wp_get_current_user();
        $who = $user && $user->exists() ? ($user->user_login . ' (#' . (int) $user->ID . ')') : ('#' . (int) get_current_user_id());
        $entry = [
            'time' => gmdate('Y-m-d H:i:s') . ' UTC',
            'user' => $who,
            'action' => sanitize_key($action),
            'details' => $details,
        ];

        if ((bool) get_option(self::OPT_AUDIT_WPLOG_ENABLED, 0)) {
            @error_log('[WIC] ' . wp_json_encode($entry, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
        }
        if ((bool) get_option(self::OPT_AUDIT_FILE_ENABLED, 1)) {
            self::audit_log_write_file_line($entry);
        }

        $log = get_option(self::OPT_AUDIT_LOG, []);
        if (!is_array($log)) {
            $log = [];
        }
        array_unshift($log, $entry);
        if (count($log) > self::AUDIT_MAX_ENTRIES) {
            $log = array_slice($log, 0, self::AUDIT_MAX_ENTRIES);
        }
        update_option(self::OPT_AUDIT_LOG, $log, false);
    }

    private static function get_audit_log(): array {
        $log = get_option(self::OPT_AUDIT_LOG, []);
        return is_array($log) ? $log : [];
    }

    private static function audit_log_write_file_line(array $entry): void {
        $uploads = wp_upload_dir();
        $base = isset($uploads['basedir']) ? (string) $uploads['basedir'] : '';
        if ($base === '' || !is_dir($base)) {
            return;
        }
        $dir = rtrim($base, '/\\') . DIRECTORY_SEPARATOR . 'wic-logs';
        if (!wp_mkdir_p($dir)) {
            return;
        }

        $index = $dir . DIRECTORY_SEPARATOR . 'index.php';
        if (!file_exists($index)) {
            @file_put_contents($index, "<?php\n// Silence is golden.\n"); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_file_put_contents
        }
        $ht = $dir . DIRECTORY_SEPARATOR . '.htaccess';
        if (!file_exists($ht)) {
            @file_put_contents($ht, "Deny from all\n<FilesMatch \"\\.log$\">\nDeny from all\n</FilesMatch>\n"); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_file_put_contents
        }

        $file = $dir . DIRECTORY_SEPARATOR . 'wic-audit.log';
        if (file_exists($file) && @filesize($file) !== false && (int) @filesize($file) > self::AUDIT_FILE_MAX_BYTES) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
            $rot = $dir . DIRECTORY_SEPARATOR . 'wic-audit.log.1';
            wp_delete_file($rot);
            @rename($file, $rot); // phpcs:ignore WordPress.WP.AlternativeFunctions.rename_rename
        }
        $line = wp_json_encode($entry, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "\n";
        @file_put_contents($file, $line, FILE_APPEND); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_file_put_contents
    }
}

BCIC_Image_Cleaner::init();


